import numpy as np
from scipy import stats, integrate
import simpy
import random
import statistics
import pandas as pd
import matplotlib.pyplot as plt
import time

start_time = time.time()
# Parameters
a1 = 90  # initial intercept for Retailer 1
b1 = 0.2 # initial scale for Retailer 1
a2 = 90  # baseline demand for Retailer 2
b2 = 0.4  # price sensitivity for Retailer 2
c = 1.5  # production cost
c1 = 1.5
s = 0.5  # storage cost for Retailers
h = 0.5  # holding cost for Retailers
weeks = 1040 # number of weeks the simulation will run
days_per_week =5 # number of days per week the simulation will run
rounds =5 # number of rounds to run
lower_bound = -2  # lower bound for Finverse mapping
upper_bound = 2   # upper bound for Finverse mapping
mu = 0
arrival_rate = 2  # average rate of customer arrivals (customers per minute)
# Define service rates for each retailer
service_rate_retailer1 = 5
service_rate_retailer2 = 5
# List to store waiting times and corresponding demands
waiting_times = []
demands = []
# Set the seed for reproducibility
seed_value = 40  # Fixed seed value for consistency
random.seed(seed_value)
np.random.seed(seed_value)
def customer(env, name, server, service_rate, waiting_times_list, service_times_list, lead_times_list):
    """Simulate a customer interacting with the server and record waiting, service, and lead times."""
    arrival_time = env.now
    with server.request() as request:
        yield request  # Wait for the server to be available
        # Start service
        start_service = env.now
        service_time = random.expovariate(service_rate)
        yield env.timeout(service_time)

        # Record waiting time, service time, and lead time
        waiting_time = start_service - arrival_time
        waiting_times_list.append(waiting_time)
        service_times_list.append(service_time)

        # Calculate and record total lead time
        total_lead_time = waiting_time + service_time
        lead_times_list.append(total_lead_time)
class CustomResource(simpy.Resource):
    def _init_(self, env, capacity):
        super()._init_(env, capacity)
        self.queue_length = 0


    def request(self, *args, **kwargs):
        self.queue_length = len(self.queue) + 1
        return super().request(*args, **kwargs)

    def release(self, *args, **kwargs):
        self.queue_length = len(self.queue)
        return super().release(*args, **kwargs)

def setup_retailer(env, arrival_rate, service_rate, waiting_times_list, service_times_list, lead_times_list, retailer_number):
    """Setup for each retailer with distinct server resources."""
    server = CustomResource(env, capacity=1)  # Create a unique server for each retailer
    while True:
        inter_arrival_time = random.expovariate(arrival_rate)
        yield env.timeout(inter_arrival_time)
        customer_name = f'Customer_{env.now:.2f}_Retailer{retailer_number}'
        env.process(customer(env, customer_name, server, service_rate, waiting_times_list, service_times_list, lead_times_list))


def calculated_Q1(z1):
    """Calculate Q(z1) for the first retailer."""
    integrand = lambda u: (u - z1) * (1/4)
    result, _ = integrate.quad(integrand, z1, 2)
    return result

def calculated_Q2(z2):
    """Calculate Q(z1) for the first retailer."""
    integrand = lambda u: (u - z2) * (1/4)
    result, _ = integrate.quad(integrand, z2, 2)
    return result
def calculated_L1(z1):
    """Calculate the integral of the difference between z1 and u weighted by the normal PDF for retailer 1."""
    integrand = lambda u: (z1 - u) * (1/4)
    result, _ = integrate.quad(integrand, -2, z1)
    return result

def calculated_L2(z2):
    """Calculate the integral of the difference between z1 and u weighted by the normal PDF for retailer 1."""
    integrand = lambda u: (z2 - u) * (1/4)
    result, _ = integrate.quad(integrand, -2, z2)
    return result


def calculate_M1(a1, b1, gamma1, avg_waiting_time1, avg_waiting_time2, delta1, alpha1, mu, z1,c,gamma_s1,delta_s1,avg_service_time1,avg_service_time2):
    """Calculate M1 based on provided parameters."""
    Q1 = calculated_Q1(z1)  # Use calculated_Q1 for retailer 1
    M1 = a1 + (b1 * c) - (gamma1 * avg_waiting_time1) + delta1 * (avg_waiting_time2 - avg_waiting_time1) - (gamma_s1 * avg_service_time1)  + (delta_s1 * (avg_service_time2 - avg_service_time1))+ (alpha1 * c) + mu - Q1
    return M1








def calculate_M2(a2, b2, gamma2, avg_waiting_time2, avg_waiting_time1, delta2, alpha2, mu, z2,c,gamma_s2,delta_s2,avg_service_time1,avg_service_time2):
    """Calculate M2 based on provided parameters."""
    Q2 = calculated_Q2(z2)  # Use calculated_Q2 for retailer 2
    M2 = a2 + (b2 * c) - (gamma2 * avg_waiting_time2) + delta2 * (avg_waiting_time1 - avg_waiting_time2) - (gamma_s2 * avg_service_time2) + (delta_s2 * (avg_service_time1 - avg_service_time2)) + (alpha2 * c) + mu - Q2
    return M2

def calculate_optimal_prices(M1, M2, a1, a2, b1, b2, alpha1, alpha2):
    """Calculate optimal prices p1 and p2 based on M1 and M2."""
    numerator_p1 = 2 * (b2 + alpha2) * M1 + (alpha1 * M2)
    numerator_p2 = (alpha2 * M1) + 2 * (b1 + alpha1) * M2
    denominator = 4 * (b1 + alpha1) * (b2 + alpha2) - (alpha1 * alpha2)
    p1 = numerator_p1 / denominator
    p2 = numerator_p2 / denominator
    return p1, p2
# Define the demand function for both retailers
def demand(p1, p2, epsilon1, epsilon2, alpha1, alpha2, delta1, delta2, gamma1, gamma2, avg_waiting_time1,
           avg_waiting_time2, avg_service_time1, avg_service_time2, a1, b1, a2, b2, gamma_s1, gamma_s2, delta_s1, delta_s2):
    demand1 = (
            a1
            - (b1 * p1)  # price effect on demand for retailer 1
            - (gamma1 * avg_waiting_time1)  # waiting time effect for retailer 1
            - (gamma_s1 * avg_service_time1)  # own service time effect for retailer 1
            - (delta_s1 * (avg_service_time2 - avg_service_time1))  # cross service time effect for retailer 1
            + epsilon1  # random shock for retailer 1
            + alpha1 * (p2 - p1)  # cross-price effect
            + delta1 * (avg_waiting_time2 - avg_waiting_time1)  # cross waiting time effect
    )

    demand2 = (
            a2
            - (b2 * p2)  # price effect on demand for retailer 2
            - (gamma2 * avg_waiting_time2)  # waiting time effect for retailer 2
            - (gamma_s2 * avg_service_time2)  # own service time effect for retailer 2
            - (delta_s2 * (avg_service_time1 - avg_service_time2))  # cross service time effect for retailer 2
            + epsilon2  # random shock for retailer 2
            + alpha2 * (p1 - p2)  # cross-price effect
            + delta2 * (avg_waiting_time1 - avg_waiting_time2)  # cross waiting time effect
    )
    return demand1, demand2
def mean_demand(p1, p2, alpha1, alpha2, delta1, delta2, gamma1, gamma2, avg_waiting_time1,
           avg_waiting_time2, avg_service_time1, avg_service_time2, a1, b1, a2, b2, gamma_s1, gamma_s2, delta_s1, delta_s2):
    mean_demand1 = (
            a1
            - (b1 * p1)  # price effect on demand for retailer 1
            - (gamma1 * avg_waiting_time1)  # waiting time effect for retailer 1
            - (gamma_s1 * avg_service_time1)  # own service time effect for retailer 1
            - (delta_s1 * (avg_service_time2 - avg_service_time1))  # cross service time effect for retailer 1
            + alpha1 * (p2 - p1)  # cross-price effect
            + delta1 * (avg_waiting_time2 - avg_waiting_time1)  # cross waiting time effect
    )
    mean_demand2 = (
            a2
            - (b2 * p2)  # price effect on demand for retailer 2
            - (gamma2 * avg_waiting_time2)  # waiting time effect for retailer 2
            - (gamma_s2 * avg_service_time2)  # own service time effect for retailer 2
            - (delta_s2 * (avg_service_time1 - avg_service_time2))  # cross service time effect for retailer 2
            + alpha2 * (p1 - p2)  # cross-price effect
            + delta2 * (avg_waiting_time1 - avg_waiting_time2)  # cross waiting time effect
    )
    return mean_demand1, mean_demand2

# Inverse function to map probability to the original range
def Finverse(p, lower_bound, upper_bound):
    """Inverse function to map probability p back to the original range."""
    return lower_bound + p * (upper_bound - lower_bound)




def calculate_z1_optimal(p1, s, c, h, lower_bound, upper_bound):
    """Calculate the optimal z for retailer 1 based on the price."""
    target_cdf_value1 = np.clip((p1 + s - c) / (p1 + s + h), 0, 1)
    #print(f"DEBUG: z1_optimal calculation -> target_cdf_value1: {target_cdf_value1}")  # Debug log
    z1_optimal = Finverse(target_cdf_value1, lower_bound, upper_bound)
    #print(f"DEBUG: z1_optimal after Finverse -> z1_optimal: {z1_optimal}")  # Debug log
    return z1_optimal




def calculate_z2_optimal(p2, s, c, h, lower_bound, upper_bound):
    """Calculate the optimal z for retailer 2 based on the price."""
    target_cdf_value2 = np.clip((p2 + s - c) / (p2 + s + h), 0, 1)
    #print(f"DEBUG: z2_optimal calculation -> target_cdf_value2: {target_cdf_value2}")  # Debug log
    z2_optimal = Finverse(target_cdf_value2, lower_bound, upper_bound)
    #print(f"DEBUG: z2_optimal after Finverse -> z2_optimal: {z2_optimal}")  # Debug log
    return z2_optimal


# Distributor profit calculation
def profit_distributor(beta, p1, p2, c1, qd,q,z1,z2):
    """Calculate the profit for the distributor for both retailers."""
    # Calculate Q and L for each retailer
    Q1 = calculated_Q1(z1)
    Q2 = calculated_Q2(z2)
    L1 = calculated_L1(z1)
    L2 = calculated_L2(z2)
    p= (p1 +p2)/2
    wd =  p / (1 + beta)
    dis_profit = ((wd - c1) * min(qd,q))- Q1-Q2-L1-L2
    return dis_profit








# Manufacturer profit calculation
def profit_manufacturer(alpha, beta, p1, p2, c1, qm,q,z1,z2):
    """Calculate the profit for the manufacturer for both retailers."""
    # Calculate Q and L for each retailer
    Q1 = calculated_Q1(z1)
    Q2 = calculated_Q2(z2)
    L1 = calculated_L1(z1)
    L2 = calculated_L2(z2)
    p = (p1+p2)/2
    wm = p / ((1 + alpha) * (1 + beta))
    man_profit = ((wm - c1) * min(qm,q))-Q1-Q2-L1-L2
    return man_profit








# Expected profit calculation with epsilon
def expected_profit_with_epsilon(z1, z2, p1, p2, alpha1, alpha2, delta1, delta2, gamma1, gamma2,
                                 avg_waiting_time1, avg_waiting_time2, avg_service_time1,
                                 avg_service_time2, a1, b1, a2, b2, gamma_s1, gamma_s2, delta_s1, delta_s2,c,h,s):
    """Calculate the expected profit with a given z, epsilon, avg_lead_time, and gamma."""

    # Call the mean_demand function to calculate mean demands
    mean_demand1, mean_demand2 = mean_demand(p1, p2, alpha1, alpha2, delta1, delta2,
                                             gamma1, gamma2, avg_waiting_time1,
                                             avg_waiting_time2, avg_service_time1,
                                             avg_service_time2, a1, b1, a2, b2,
                                             gamma_s1, gamma_s2, delta_s1, delta_s2)








    # Profit components for retailer 1
    C_p1 = (p1 - c) * mean_demand1
    L_z_p1 = (c + h) * calculated_L1(z1) + (p1 + s - c) * calculated_Q1(z1)
    r1_profit = C_p1 - L_z_p1








    # Profit components for retailer 2
    C_p2 = (p2 - c) * mean_demand2
    L_z_p2 = (c + h) * calculated_L2(z2) + (p2 + s - c) * calculated_Q2(z2)
    r2_profit = C_p2 - L_z_p2








    return r1_profit, r2_profit








def run_simulation(round_num):
    """Run the simulation for a specified number of weeks and days."""
    all_data = []
    z1 = 0
    z2 = 0


    for week in range(weeks):  # Start week from 0
        weekly_summary = {'week': week + 1, 'days': []}  # Store week as week + 1

        # Generate weekly values for both retailers
        epsilon1_weekly = np.random.uniform(-2,2)
        epsilon2_weekly = np.random.uniform(-2,2)
        alpha1_weekly = np.random.uniform(0, 1)
        alpha_weekly = np.random.uniform(0, 1)
        beta_weekly = np.random.uniform(0, 1)
        alpha2_weekly = np.random.uniform(0, 1)
        beta1_weekly = np.random.uniform(0, 1)
        beta2_weekly = np.random.uniform(0, 1)
        gamma1_weekly = np.random.uniform(0, 1)
        gamma2_weekly = np.random.uniform(0, 1)
        delta1_weekly = np.random.uniform(0, 1)
        delta2_weekly = np.random.uniform(0, 1)
        gamma_s1_weekly = np.random.uniform(0, 1)
        gamma_s2_weekly = np.random.uniform(0, 1)
        delta_s1_weekly = np.random.uniform(0, 1)
        delta_s2_weekly = np.random.uniform(0, 1)
        x = np.random.uniform (-4,4)
        y = np.random.uniform(-5,5)


        for day in range(1, days_per_week + 1):
            print(f"Running week {week + 1}, day {day}")  # Debug print
            env = simpy.Environment()  # Reset environment each day


            waiting_times_list1 = []
            waiting_times_list2 = []
            service_times_list1 = []
            service_times_list2 = []
            lead_times_list1 = []  # For retailer 1
            lead_times_list2 = []  # For retailer 2
            start_time = env.now
            end_time = start_time + 480  # 8 hours = 480 minutes


            # Start the processes
            env.process(setup_retailer(env, arrival_rate, service_rate_retailer1, waiting_times_list1, service_times_list1,lead_times_list1, 1))  # Retailer 1
            env.process(setup_retailer(env, arrival_rate, service_rate_retailer2, waiting_times_list2, service_times_list2,lead_times_list2, 2))  # Retailer 2
            # Run the simulation
            env.run(until=end_time)
            # Calculate average waiting time for each retailer
            avg_waiting_time1 = np.mean(waiting_times_list1) if waiting_times_list1 else 0
            avg_waiting_time2 = np.mean(waiting_times_list2) if waiting_times_list1 else 0
            avg_service_time1 = np.mean(service_times_list1) if service_times_list1 else 0
            avg_service_time2 = np.mean(service_times_list2) if service_times_list2 else 0
            avg_lead_time1 = np.mean(lead_times_list1) if lead_times_list1 else 0
            avg_lead_time2 = np.mean(lead_times_list2) if lead_times_list2 else 0

            Q1 = calculated_Q1(z1)
            Q2 = calculated_Q2(z2)


            # Now use them
            M1 = calculate_M1(a1, b1, gamma1_weekly, avg_waiting_time1, avg_waiting_time2, delta1_weekly, alpha1_weekly, mu, z1,c,gamma_s1_weekly,delta_s1_weekly,avg_service_time1, avg_service_time2)
            M2 = calculate_M2(a2, b2, gamma2_weekly, avg_waiting_time2, avg_waiting_time1, delta2_weekly, alpha2_weekly, mu, z2,c,gamma_s2_weekly,delta_s2_weekly,avg_service_time1, avg_service_time2)
            # Calculate optimal prices
            p1, p2 = calculate_optimal_prices(M1, M2, a1, a2, b1, b2, alpha1_weekly, alpha2_weekly)

            # Calculate new z_optimal values (if necessary)
            z1_optimal = calculate_z1_optimal(p1, s, c, h, lower_bound, upper_bound)
            z2_optimal = calculate_z2_optimal(p2, s, c, h, lower_bound, upper_bound)

            # Calculate demand for the day
            demand1, demand2 = demand(p1, p2, epsilon1_weekly, epsilon2_weekly, alpha1_weekly, alpha2_weekly, delta1_weekly, delta2_weekly, gamma1_weekly, gamma2_weekly, avg_waiting_time1,
           avg_waiting_time2, avg_service_time1, avg_service_time2, a1, b1, a2, b2, gamma_s1_weekly, gamma_s2_weekly, delta_s1_weekly, delta_s2_weekly)
            # Calculate mean demand for both retailers
            mean_demand1 = a1 - (b1 * p1) - (gamma1_weekly * avg_waiting_time1) + alpha1_weekly * (
                        p2 - p1) + delta1_weekly * (avg_waiting_time2 - avg_waiting_time1)
            mean_demand2 = a2 - (b2 * p2) - (gamma2_weekly * avg_waiting_time2) + alpha2_weekly * (
                        p1 - p2) + delta2_weekly * (avg_waiting_time1 - avg_waiting_time2)

            q1_optimal = z1_optimal + mean_demand1  # Calculate q_optimal for retailer1
            q2_optimal = z2_optimal + mean_demand2   # Calculate q_optimal for retailer2
            q_optimal = q1_optimal + q2_optimal

            qd= q_optimal + x # distributor order
            qm = qd + y # manufacturer order

            # Calculate expected profit
            r1_profit, r2_profit = expected_profit_with_epsilon(z1, z2, p1, p2, alpha1_weekly, alpha2_weekly, delta1_weekly, delta2_weekly, gamma1_weekly, gamma2_weekly,
                                 avg_waiting_time1, avg_waiting_time2, avg_service_time1,
                                 avg_service_time2, a1, b1, a2, b2, gamma_s1_weekly, gamma_s2_weekly, delta_s1_weekly, delta_s2_weekly,c,h,s)


            distributor_profit = profit_distributor(beta_weekly, p1, p2, c1, qd,q_optimal,z1_optimal,z2_optimal)
            manufacturer_profit = profit_manufacturer(alpha_weekly, beta_weekly, p1, p2, c1, qm,q_optimal,z1_optimal,z2_optimal)



            all_data.append({
                'Round': round_num + 1,
                'Week': week + 1,  # Store week as week + 1
                'Day': day,
                'optimal_price_retailer1': p1,
                'optimal_price_retailer2': p2,
                'demand of retailer1': demand1,
                'demand of retailer2': demand2,
                'optimal_stock_level of retailer1': z1_optimal,
                'optimal_stock_level of retailer2': z2_optimal,
                'q_optimal of retailer1': q1_optimal,
                'q_optimal of retailer2': q2_optimal,
                'total order': qm,
                'distributor order':qd,
                'retailer1_profit': r1_profit,
                'retailer2_profit': r2_profit,
                'distributor_profit': distributor_profit,
                'manufacturer_profit': manufacturer_profit,
                'Avg Waiting Time1': avg_waiting_time1,  # Retailer 1
                'Avg Waiting Time2': avg_waiting_time2,  # Retailer 2
                'Avg lead Time1': avg_lead_time1,  # Retailer 1
                'Avg lead Time2': avg_lead_time2,  # Retailer 2
                'Avg service Time1': avg_service_time1,  # Retailer 1
                'Avg service Time2': avg_service_time2,  # Retailer 2
                'epsilon1': epsilon1_weekly,
                'epsilon2': epsilon2_weekly,
                'alpha1':alpha1_weekly,
                'alpha':alpha_weekly,
                'beta':beta_weekly,
                'alpha2':alpha2_weekly,
                'beta1':beta1_weekly,
                'beta2': beta2_weekly,
                'gamma1': gamma1_weekly,
                'gamma2': gamma2_weekly,
                'delta1':delta1_weekly,
                'delta2': delta2_weekly,
                'gamma_s1':gamma_s1_weekly,
                'gamma_s2':gamma_s2_weekly,
                'delta_s1':delta_s1_weekly,
                'delta_s2':delta_s2_weekly,
                'x':x,
                'y':y
            })
            # Update z1 and z2 for the next day
            z1 = z1_optimal
            z2 = z2_optimal
    print(f"Data collected for round {round_num + 1}: {len(all_data)} entries")  # Debug print




    return all_data

def run_multiple_rounds(rounds):
    """Run multiple rounds of the simulation and save all results to a DataFrame."""
    all_rounds_data = []


    # Run each round
    for round_num in range(rounds):
        print(f"Running round {round_num + 1}")  # Debug print
        round_data = run_simulation(round_num)
        all_rounds_data.extend(round_data)  # Append data from this round to all_rounds_data

    # Create a DataFrame from the combined data of all rounds
    df = pd.DataFrame(all_rounds_data)


    # Save to Excel with a unique filename to avoid overwriting
    filename = f'simulation_resultss0.xlsx'
    df.to_excel(filename, index=False)
    print(f"Simulation results saved to {filename}")
    end_time = time.time()  # End timing for entire simulation
    total_elapsed_time = end_time - start_time
    # Calculate variance for Retailer 1
    var_q_m = np.var(df['total order'])
    var_demand1 = np.var(df['demand of retailer1'])


    # Calculate variance for Retailer 2
    var_demand2 = np.var(df['demand of retailer2'])


    # Bullwhip effect for Retailer 1
    bullwhip_effect_r1 = var_q_m / var_demand1


    # Bullwhip effect for Retailer 2
    bullwhip_effect_r2 = var_q_m / var_demand2

    # Overall Bullwhip Effect (average of both retailers)
    overall_bullwhip_effect = (bullwhip_effect_r1 + bullwhip_effect_r2) / 2


    # Print results
    print(f"Retailer 1 Bullwhip Effect: {bullwhip_effect_r1}")
    print(f"Retailer 2 Bullwhip Effect: {bullwhip_effect_r2}")
    print(f"Overall Bullwhip Effect: {overall_bullwhip_effect}")

    return df

# Running the simulation for multiple rounds and saving to Excel
df= run_multiple_rounds(rounds)
print(df)

# Group by 'Round' and 'Week' to sum the required columns over the 5 days of each week for each round
df = df.groupby(['Round', 'Week'])[['optimal_price_retailer1', 'optimal_price_retailer2', 'demand of retailer1', 'demand of retailer2', 'optimal_stock_level of retailer1',
                'optimal_stock_level of retailer2', 'q_optimal of retailer1', 'q_optimal of retailer2', 'total order', 'retailer1_profit', 'retailer2_profit',
                'distributor_profit', 'manufacturer_profit', 'Avg Waiting Time1', 'Avg Waiting Time2', 'Avg lead Time1', 'Avg lead Time2', 'Avg service Time1', 'Avg service Time2',
                'epsilon1', 'epsilon2', 'distributor order','alpha1', 'alpha', 'beta', 'alpha2','beta1', 'beta2', 'gamma1', 'gamma2', 'delta1', 'delta2', 'gamma_s1', 'gamma_s2', 'delta_s1', 'delta_s2', 'x', 'y']].mean().reset_index()
# Calculate weekly averages across rounds
data = df.groupby('Week')[['optimal_price_retailer1', 'optimal_price_retailer2', 'demand of retailer1', 'demand of retailer2', 'optimal_stock_level of retailer1',
                'optimal_stock_level of retailer2', 'q_optimal of retailer1', 'q_optimal of retailer2', 'total order', 'retailer1_profit', 'retailer2_profit',
                'distributor_profit', 'manufacturer_profit', 'Avg Waiting Time1', 'Avg Waiting Time2', 'Avg lead Time1', 'Avg lead Time2', 'Avg service Time1', 'Avg service Time2',
                'epsilon1', 'epsilon2','distributor order', 'alpha1', 'alpha', 'beta', 'alpha2','beta1', 'beta2', 'gamma1', 'gamma2', 'delta1', 'delta2', 'gamma_s1', 'gamma_s2', 'delta_s1', 'delta_s2', 'x', 'y']].mean().reset_index()
print(data)

# Calculating cumulative averages
data['Cumulative Avg of optimal price retailer1'] = data['optimal_price_retailer1'].expanding().mean()
data['Cumulative Avg of optimal price retailer2'] = data['optimal_price_retailer2'].expanding().mean()
data["Cumulative Avg Retailer1's Demand"] = data['demand of retailer1'].expanding().mean()
data["Cumulative Avg Retailer2's Demand"] = data['demand of retailer2'].expanding().mean()
data["Cumulative Avg Retailer1's stock"] = data['q_optimal of retailer1'].expanding().mean()
data["Cumulative Avg Retailer2's stock"] = data['q_optimal of retailer2'].expanding().mean()
data["Cumulative Avg Distributor's stock"] = data['distributor order'].expanding().mean()
data["Cumulative Avg Manufacturer's stock"] = data['total order'].expanding().mean()
data["Cumulative Avg Manufacturer Profit"] = data["manufacturer_profit"].expanding().mean()
data["Cumulative Avg Distributor Profit"] = data["distributor_profit"].expanding().mean()
data["Cumulative Avg retailer1's Profit"] = data['retailer1_profit'].expanding().mean()
data["Cumulative Avg retailer2's Profit"] = data['retailer2_profit'].expanding().mean()
data['Cumulative Avg Service Time1'] = data['Avg service Time1'].expanding().mean()
data['Cumulative Avg Service Time2'] = data['Avg service Time2'].expanding().mean()
data["Cumulative Avg Waiting Time1"] = data["Avg Waiting Time1"].expanding().mean()
data["Cumulative Avg Waiting Time2"] = data["Avg Waiting Time2"].expanding().mean()
data["Cumulative Avg Lead Time1"] = data["Avg lead Time1"].expanding().mean()
data["Cumulative Avg Lead Time2"] = data["Avg lead Time2"].expanding().mean()

# Plotting cumulative average results for each week
fig, axes = plt.subplots(3, 3, figsize=(12, 14))

# Plot cumulative average manufacturer profit
axes[0, 0].plot(data['Week'], data['Cumulative Avg Manufacturer Profit'], marker='o')
axes[0, 0].set_title('Cumulative Avg Manufacturer Profit per Week', pad=20)
axes[0, 0].set_xlabel('Week')
axes[0, 0].set_ylabel('Cumulative Avg Manufacturer Profit')
axes[0, 0].grid(True)

# Plot cumulative average retailer 1 and retailer 2 profit
axes[0, 1].plot(data['Week'], data["Cumulative Avg retailer1's Profit"], marker='o', label='Retailer 1')
axes[0, 1].plot(data['Week'], data["Cumulative Avg retailer2's Profit"], marker='o', label='Retailer 2')
axes[0, 1].set_title('Cumulative Avg Retailer Profit per Week', pad=20)
axes[0, 1].set_xlabel('Week')
axes[0, 1].set_ylabel('Cumulative Avg Retailer Profit')
axes[0, 1].grid(True)
axes[0, 1].legend()

# Plot cumulative average distributor profit
axes[0, 2].plot(data['Week'], data["Cumulative Avg Distributor Profit"], marker='o')
axes[0, 2].set_title('Cumulative Avg Distributor Profit per Week', pad=20)
axes[0, 2].set_xlabel('Week')
axes[0, 2].set_ylabel('Cumulative Avg Distributor Profit')
axes[0, 2].grid(True)

# Plot cumulative average demand for retailer 1 and retailer 2
axes[1, 0].plot(data['Week'], data["Cumulative Avg Retailer1's Demand"], marker='o', label='Demand 1')
axes[1, 0].plot(data['Week'], data["Cumulative Avg Retailer2's Demand"], marker='o', label='Demand 2')
axes[1, 0].set_title('Cumulative Avg Demand per Week', pad=20)
axes[1, 0].set_xlabel('Week')
axes[1, 0].set_ylabel('Cumulative Avg Demand')
axes[1, 0].grid(True)
axes[1, 0].legend()


# Plot optimal price over time for retailer 1 and retailer 2
axes[1, 1].plot(data['Week'], data['Cumulative Avg of optimal price retailer1'], marker='o', label='Retailer 1 Price')
axes[1, 1].plot(data['Week'], data['Cumulative Avg of optimal price retailer2'], marker='o', label='Retailer 2 Price')
axes[1, 1].set_title('Optimal Price per Week', pad=20)
axes[1, 1].set_xlabel('Week')
axes[1, 1].set_ylabel('Optimal Price')
axes[1, 1].grid(True)
axes[1, 1].legend()


# Plot optimal quantity over time for retailer 1 and retailer 2
axes[1, 2].plot(data['Week'], data["Cumulative Avg Retailer1's stock"], marker='o', label='Retailer 1 Quantity')
axes[1, 2].plot(data['Week'], data["Cumulative Avg Retailer2's stock"], marker='o', label='Retailer 2 Quantity')
axes[1, 2].set_title('Optimal Quantity per Week', pad=20)
axes[1, 2].set_xlabel('Week')
axes[1, 2].set_ylabel('Optimal Quantity')
axes[1, 2].grid(True)
axes[1, 2].legend()


# Plot cumulative average service time for retailer 1 and retailer 2
axes[2, 1].plot(data['Week'], data['Cumulative Avg Service Time1'], marker='o', label='Retailer 1')
axes[2, 1].plot(data['Week'], data['Cumulative Avg Service Time2'], marker='o', label='Retailer 2')
axes[2, 1].set_title('Cumulative Avg Service Time of Retailer per Week', pad=20)
axes[2, 1].set_xlabel('Week')
axes[2, 1].set_ylabel('Cumulative Avg Service Time')
axes[2, 1].grid(True)
axes[2, 1].legend()


# Plot cumulative average waiting time for retailer 1 and retailer 2
axes[2, 0].plot(data['Week'], data['Cumulative Avg Waiting Time1'], marker='o', label='Retailer 1')
axes[2, 0].plot(data['Week'], data['Cumulative Avg Waiting Time2'], marker='o', label='Retailer 2')
axes[2, 0].set_title('Cumulative Avg Waiting Time per Week', pad=20)
axes[2, 0].set_xlabel('Week')
axes[2, 0].set_ylabel('Cumulative Avg Waiting Time')
axes[2, 0].grid(True)
axes[2, 0].legend()


# Plot cumulative average waiting time for retailer 1 and retailer 2
axes[2, 2].plot(data['Week'], data['Cumulative Avg Lead Time1'], marker='o', label='Retailer 1')
axes[2, 2].plot(data['Week'], data['Cumulative Avg Lead Time2'], marker='o', label='Retailer 2')
axes[2, 2].set_title('Cumulative Avg lead Time per Week', pad=20)
axes[2, 2].set_xlabel('Week')
axes[2, 2].set_ylabel('Cumulative Avg lead Time')
axes[2, 2].grid(True)
axes[2, 2].legend()


# Adjust spacing for more clarity between plots
plt.subplots_adjust(left=0.1, right=0.9, top=0.95, bottom=0.05, wspace=0.4, hspace=0.7)


# Save the figure
fig.savefig('cumulative_averagess0.png', dpi=300, bbox_inches='tight')


# Show the plot
plt.show()

# Calculating std
data['std of optimal price retailer1'] = data['optimal_price_retailer1'].rolling(window=52).std()
data['std of optimal price retailer2'] = data['optimal_price_retailer2'].rolling(window=52).std()
data["std Retailer1's Demand"] = data['demand of retailer1'].rolling(window=52).std()
data["std Retailer2's Demand"] = data['demand of retailer2'].rolling(window=52).std()
data["std Retailer1's stock"] = data['q_optimal of retailer1'].rolling(window=52).std()
data["std Retailer2's stock"] = data['q_optimal of retailer2'].rolling(window=52).std()
data["std Distributor's stock"] = data['distributor order'].rolling(window=52).std()
data["std Manufacturer's stock"] = data['total order'].rolling(window=52).std()
data["std Manufacturer Profit"] = data["manufacturer_profit"].rolling(window=52).std()
data["std Distributor Profit"] = data["distributor_profit"].rolling(window=52).std()
data["std retailer1's Profit"] = data['retailer1_profit'].rolling(window=52).std()
data["std retailer2's Profit"] = data['retailer2_profit'].rolling(window=52).std()
data['std Service Time1'] = data['Avg service Time1'].rolling(window=52).std()
data['std Service Time2'] = data['Avg service Time2'].rolling(window=52).std()
data["std Waiting Time1"] = data["Avg Waiting Time1"].rolling(window=52).std()
data["std Waiting Time2"] = data["Avg Waiting Time2"].rolling(window=52).std()
data["std Lead Time1"] = data["Avg lead Time1"].rolling(window=52).std()
data["std Lead Time2"] = data["Avg lead Time2"].rolling(window=52).std()
# Plotting cumulative average results for each week
fig, axes = plt.subplots(3, 3, figsize=(12, 14))

# Plot cumulative average manufacturer profit
axes[0, 0].plot(data['Week'], data['std Manufacturer Profit'], marker='o')
axes[0, 0].set_title('std Manufacturer Profit per Week', pad=20)
axes[0, 0].set_xlabel('Week')
axes[0, 0].set_ylabel('std Manufacturer Profit')
axes[0, 0].grid(True)

# Plot cumulative average retailer 1 and retailer 2 profit
axes[0, 1].plot(data['Week'], data["std retailer1's Profit"], marker='o', label='Retailer 1')
axes[0, 1].plot(data['Week'], data["std retailer2's Profit"], marker='o', label='Retailer 2')
axes[0, 1].set_title('std Retailer Profit per Week', pad=20)
axes[0, 1].set_xlabel('Week')
axes[0, 1].set_ylabel('std Retailer Profit')
axes[0, 1].grid(True)
axes[0, 1].legend()

# Plot cumulative average distributor profit
axes[0, 2].plot(data['Week'], data["std Distributor Profit"], marker='o')
axes[0, 2].set_title('std Distributor Profit per Week', pad=20)
axes[0, 2].set_xlabel('Week')
axes[0, 2].set_ylabel('std Distributor Profit')
axes[0, 2].grid(True)

# Plot cumulative average demand for retailer 1 and retailer 2
axes[1, 0].plot(data['Week'], data["std Retailer1's Demand"], marker='o', label='Demand 1')
axes[1, 0].plot(data['Week'], data["std Retailer2's Demand"], marker='o', label='Demand 2')
axes[1, 0].set_title('std Demand per Week', pad=20)
axes[1, 0].set_xlabel('Week')
axes[1, 0].set_ylabel('std Demand')
axes[1, 0].grid(True)
axes[1, 0].legend()


# Plot optimal price over time for retailer 1 and retailer 2
axes[1, 1].plot(data['Week'], data['std of optimal price retailer1'], marker='o', label='Retailer 1 Price')
axes[1, 1].plot(data['Week'], data['std of optimal price retailer2'], marker='o', label='Retailer 2 Price')
axes[1, 1].set_title('std of Optimal Price per Week', pad=20)
axes[1, 1].set_xlabel('Week')
axes[1, 1].set_ylabel('std of Optimal Price')
axes[1, 1].grid(True)
axes[1, 1].legend()


# Plot optimal quantity over time for retailer 1 and retailer 2
axes[1, 2].plot(data['Week'], data["std Retailer1's stock"], marker='o', label='Retailer 1 Quantity')
axes[1, 2].plot(data['Week'], data["std Retailer2's stock"], marker='o', label='Retailer 2 Quantity')
axes[1, 2].set_title('std of Optimal Quantity per Week', pad=20)
axes[1, 2].set_xlabel('Week')
axes[1, 2].set_ylabel('std of Optimal Quantity')
axes[1, 2].grid(True)
axes[1, 2].legend()


# Plot cumulative average service time for retailer 1 and retailer 2
axes[2, 1].plot(data['Week'], data['std Service Time1'], marker='o', label='Retailer 1')
axes[2, 1].plot(data['Week'], data['std Service Time2'], marker='o', label='Retailer 2')
axes[2, 1].set_title('std Service Time of Retailer per Week', pad=20)
axes[2, 1].set_xlabel('Week')
axes[2, 1].set_ylabel('std Service Time')
axes[2, 1].grid(True)
axes[2, 1].legend()


# Plot cumulative average waiting time for retailer 1 and retailer 2
axes[2, 0].plot(data['Week'], data['std Waiting Time1'], marker='o', label='Retailer 1')
axes[2, 0].plot(data['Week'], data['std Waiting Time2'], marker='o', label='Retailer 2')
axes[2, 0].set_title('std Waiting Time per Week', pad=20)
axes[2, 0].set_xlabel('Week')
axes[2, 0].set_ylabel('std Waiting Time')
axes[2, 0].grid(True)
axes[2, 0].legend()


# Plot cumulative average waiting time for retailer 1 and retailer 2
axes[2, 2].plot(data['Week'], data['std Lead Time1'], marker='o', label='Retailer 1')
axes[2, 2].plot(data['Week'], data['std Lead Time2'], marker='o', label='Retailer 2')
axes[2, 2].set_title('std lead Time per Week', pad=20)
axes[2, 2].set_xlabel('Week')
axes[2, 2].set_ylabel('std lead Time')
axes[2, 2].grid(True)
axes[2, 2].legend()

# Adjust spacing for more clarity between plots
plt.subplots_adjust(left=0.1, right=0.9, top=0.95, bottom=0.05, wspace=0.4, hspace=0.7)

# Save the figure
fig.savefig('cumulative_averagess0.png', dpi=300, bbox_inches='tight')

# Show the plot
plt.show()

print(f"Total time taken to complete the entire simulation: {total_elapsed_time:.2f} seconds.")
