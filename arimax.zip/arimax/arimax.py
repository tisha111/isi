import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller
import time

start_time = time.time()

file_path = "C:/Users/User/Downloads/opt.csv"
df1 = pd.read_csv(file_path)


# Group by 'Round' and 'Week' to sum the required columns over the 5 days of each week for each round
df = df1.groupby(['Round', 'Week'])[['demand of retailer1', 'optimal_price_retailer1',
                                     'optimal_price_retailer2', 'Avg Waiting Time1',
                                     'Avg Waiting Time2', 'Avg service Time1',
                                     'Avg service Time2', 'total order', 'demand of retailer2',
                                     'optimal_stock_level of retailer1', 'optimal_stock_level of retailer2', 'epsilon1',
                                     'epsilon2', 'x', 'y']].mean().reset_index()
# print(df)
# Calculate weekly averages across rounds
weekly_avg = df.groupby('Week')[['demand of retailer1', 'optimal_price_retailer1',
                                 'optimal_price_retailer2', 'Avg Waiting Time1',
                                 'Avg Waiting Time2', 'Avg service Time1',
                                 'Avg service Time2', 'total order', 'demand of retailer2',
                                 'optimal_stock_level of retailer1', 'optimal_stock_level of retailer2', 'epsilon1',
                                 'epsilon2', 'x', 'y']].mean().reset_index()


# print(weekly_avg)


# Set the index to 'Week' for plotting
weekly_avg.set_index('Week', inplace=True)


# Plot Total Order by Week
plt.figure(figsize=(10, 6))
plt.plot(weekly_avg.index, weekly_avg['total order'], marker='o', linestyle='-', color='blue', linewidth=2)
plt.title('Total Order by Week', fontsize=16)
plt.xlabel('Week', fontsize=14)
plt.ylabel('Total Inventory', fontsize=14)
plt.grid(True, linestyle='--', alpha=0.7)
plt.show()


# Plot Demand of Retailer 1 by Week
plt.figure(figsize=(10, 6))
plt.plot(weekly_avg.index, weekly_avg['demand of retailer1'], marker='s', linestyle='-', color='orange', linewidth=2)
plt.title('Demand of Retailer 1 by Week', fontsize=16)
plt.xlabel('Week', fontsize=14)
plt.ylabel('Demand of Retailer 1', fontsize=14)
plt.grid(True, linestyle='--', alpha=0.7)
plt.show()


# Plot Demand of Retailer 2 by Week
plt.figure(figsize=(10, 6))
plt.plot(weekly_avg.index, weekly_avg['demand of retailer2'], marker='^', linestyle='-', color='green', linewidth=2)
plt.title('Demand of Retailer 2 by Week', fontsize=16)
plt.xlabel('Week', fontsize=14)
plt.ylabel('Demand of Retailer 2', fontsize=14)
plt.grid(True, linestyle='--', alpha=0.7)
plt.show()
# Define target variables for demand1, demand2, and total orders
targets = {
    'Retailer 1 Demand': weekly_avg['demand of retailer1'],
    'Retailer 2 Demand': weekly_avg['demand of retailer2'],
    'Total Orders': weekly_avg['total order']
}

# Loop through each target variable and perform the ADF test
for name, target in targets.items():
    result = adfuller(target)
    print(f'ADF Statistic for {name} (Round 1): {result[0]}')
    print(f'p-value for {name} (Round 1): {result[1]}')

    if result[1] < 0.05:
        print(f"{name} is stationary, no differencing required (d=0)\n")
    else:
        print(f"{name} is non-stationary, differencing required\n")

# Import necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_absolute_percentage_error, mean_squared_error




# Define a function to train and forecast ARIMAX model for a retailer
def run_arimax_model(dependent_var, independent_vars, order, seasonal_order, retailer_name):
    # Create exogenous DataFrame
    exog = weekly_avg[independent_vars]


    # Calculate the 80% training size based on the length of the data
    train_size = int(len(weekly_avg) * 0.8)


    # Split the data sequentially (non-randomly) for training and testing
    train = weekly_avg.iloc[:train_size].reset_index(drop=True)
    test = weekly_avg.iloc[train_size:].reset_index(drop=True)


    # Similarly split the exogenous variables data
    exog_train = exog.iloc[:train_size].reset_index(drop=True)
    exog_test = exog.iloc[train_size:].reset_index(drop=True)


    # Check if test data is empty
    if test.empty:
        print(f"No sufficient test data available after splitting for {retailer_name}.")
        return None, None


    # Fit ARIMAX model
    try:
        arimax_model = ARIMA(train[dependent_var],
                             order=order,
                             seasonal_order=seasonal_order,
                             exog=exog_train)
        arimax_result = arimax_model.fit()


        # Forecast on the test set
        forecast_arimax = arimax_result.forecast(steps=len(test), exog=exog_test)
        test['Predicted'] = forecast_arimax.reset_index(drop=True)  # Add predictions to the test set


        # Create DataFrame with test data and predictions
        results_df = test[[dependent_var, 'Predicted']].copy()
        results_df.columns = [f'Test {retailer_name}', f'Predicted {retailer_name}']


        # Calculate evaluation metrics
        mape = mean_absolute_percentage_error(test[dependent_var], test['Predicted'])
        mse = mean_squared_error(test[dependent_var], test['Predicted'])
        rmse = np.sqrt(mse)


        return results_df, (mape, mse, rmse)


    except Exception as e:
        print(f"Failed to fit ARIMAX model for {retailer_name}: {e}")
        return None, None




# Run ARIMAX model for retailer1
results_r1, metrics_r1 = run_arimax_model(
    dependent_var='demand of retailer1',
    independent_vars=[
        'optimal_price_retailer1',
        'optimal_price_retailer2',
        'Avg Waiting Time1',
        'Avg Waiting Time2',
        'Avg service Time1',
        'Avg service Time2'
    ],
    order=(2, 0, 1),  # Example order for retailer1
    seasonal_order=(2, 0, 0, 12),  # Seasonal order for retailer1
    retailer_name='Retailer 1'
)


# Run ARIMAX model for retailer2
results_r2, metrics_r2 = run_arimax_model(
    dependent_var='demand of retailer2',
    independent_vars=[
        'optimal_price_retailer2',
        'optimal_price_retailer1',
        'Avg Waiting Time2',
        'Avg Waiting Time1',
        'Avg service Time2',
        'Avg service Time1'
    ],
    order=(0, 0, 0),  # Example order for retailer2
    seasonal_order=(1, 0, 0, 12),  # Seasonal order for retailer2
    retailer_name='Retailer 2'
)
# Run ARIMAX model for total order
results_total_order, metrics_total_order = run_arimax_model(
    dependent_var='total order',
    independent_vars=[
        'optimal_price_retailer1',
        'optimal_price_retailer2',
        'Avg Waiting Time1',
        'Avg Waiting Time2',
        'Avg service Time1',
        'Avg service Time2',
        'optimal_stock_level of retailer1',
        'optimal_stock_level of retailer1'
    ],
    order=(0, 0, 0),  # Example order for total order
    seasonal_order=(0, 0, 1, 12),  # Seasonal order for total order
    retailer_name='Total Order'
)
# Combine results into a single DataFrame
if results_r1 is not None and results_r2 is not None and results_total_order is not None:
    combined_results = pd.concat([results_r1, results_r2, results_total_order], axis=1)
    print("\nCombined Test and Predicted Data:")
    print(combined_results)
    output_file_path = "C:/Users/User/Downloads/arimax_results.csv"
    combined_results.to_csv(output_file_path, index=False)
    print(f"Combined results saved to {output_file_path}")


    # Plotting the results for both retailers and total order
    plt.figure(figsize=(21, 7))


    # Retailer 1
    plt.subplot(1, 3, 1)
    plt.plot(results_r1.index, results_r1[f'Test Retailer 1'], label='Test Retailer 1', color='green', alpha=0.6)
    plt.plot(results_r1.index, results_r1[f'Predicted Retailer 1'], label='Predicted Retailer 1', color='red',
             linestyle='--', alpha=0.6)
    plt.title('Retailer 1: Test vs Predicted')
    plt.xlabel('Time')
    plt.ylabel('Demand')
    plt.legend()
    plt.grid()


    # Retailer 2
    plt.subplot(1, 3, 2)
    plt.plot(results_r2.index, results_r2[f'Test Retailer 2'], label='Test Retailer 2', color='green', alpha=0.6)
    plt.plot(results_r2.index, results_r2[f'Predicted Retailer 2'], label='Predicted Retailer 2', color='red',
             linestyle='--', alpha=0.6)
    plt.title('Retailer 2: Test vs Predicted')
    plt.xlabel('Time')
    plt.ylabel('Demand')
    plt.legend()
    plt.grid()


    # Total Order
    plt.subplot(1, 3, 3)
    plt.plot(results_total_order.index, results_total_order[f'Test Total Order'], label='Test Total Order',
             color='green', alpha=0.6)
    plt.plot(results_total_order.index, results_total_order[f'Predicted Total Order'], label='Predicted Total Order',
             color='red', linestyle='--', alpha=0.6)
    plt.title('Total Order: Test vs Predicted')
    plt.xlabel('Time')
    plt.ylabel('Total Order')
    plt.legend()
    plt.grid()


    plt.tight_layout()
    plt.show()


    # Print evaluation metrics for all three models
    print(f'\nEvaluation Metrics for Retailer 1:')
    print(f'MAPE: {metrics_r1[0] * 100:.2f}%')
    print(f'MSE: {metrics_r1[1]:.2f}')
    print(f'RMSE: {metrics_r1[2]:.2f}')


    print(f'\nEvaluation Metrics for Retailer 2:')
    print(f'MAPE: {metrics_r2[0] * 100:.2f}%')
    print(f'MSE: {metrics_r2[1]:.2f}')
    print(f'RMSE: {metrics_r2[2]:.2f}')


    print(f'\nEvaluation Metrics for Total Order:')
    print(f'MAPE: {metrics_total_order[0] * 100:.2f}%')
    print(f'MSE: {metrics_total_order[1]:.2f}')
    print(f'RMSE: {metrics_total_order[2]:.2f}')
else:
    print("One of the models did not return valid results.")
print(combined_results)


# Calculate variances
var_total_order = combined_results['Test Total Order'].var(ddof=1)
var_retailer1_demand = combined_results['Test Retailer 1'].var(ddof=1)


var_retailer2_demand = combined_results['Test Retailer 2'].var(ddof=1)


# Calculate bullwhip effects
bullwhip_effect_retailer1 = var_total_order / var_retailer1_demand
bullwhip_effect_retailer2 = var_total_order / var_retailer2_demand


# Calculate the average bullwhip effect
average_bullwhip_effect = (bullwhip_effect_retailer1 + bullwhip_effect_retailer2) / 2


# Print the results
print("Actual Bullwhip Effect for Retailer 1:", bullwhip_effect_retailer1)
print("Actual Bullwhip Effect for Retailer 2:", bullwhip_effect_retailer2)
print("Actual Average Bullwhip Effect:", average_bullwhip_effect)
# Calculate variances
pvar_total_order = combined_results['Predicted Total Order'].var(ddof=1)
pvar_retailer1_demand = combined_results['Predicted Retailer 1'].var(ddof=1)


pvar_retailer2_demand = combined_results['Predicted Retailer 2'].var(ddof=1)


# Calculate bullwhip effects
pbullwhip_effect_retailer1 = pvar_total_order / pvar_retailer1_demand
pbullwhip_effect_retailer2 = pvar_total_order / pvar_retailer2_demand


# Calculate the average bullwhip effect
paverage_bullwhip_effect = (pbullwhip_effect_retailer1 + pbullwhip_effect_retailer2) / 2


# Print the results
print(" Predicted Bullwhip Effect for Retailer 1:", pbullwhip_effect_retailer1)
print("  Predicted Bullwhip Effect for Retailer 2:", pbullwhip_effect_retailer2)
print("  Predicted Average Bullwhip Effect:", paverage_bullwhip_effect)
end_time = time.time()  # End timing for entire simulation
total_elapsed_time = end_time - start_time
print(f"Total time taken to complete the entire simulation: {total_elapsed_time:.2f} seconds.")
